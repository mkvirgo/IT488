from flask import render_template, request, jsonify

def home():
    return "hello" 
