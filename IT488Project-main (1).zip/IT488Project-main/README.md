# To Run
## Open two terminals

## CD into backend/

### run pipenv install
### run pipenv shell
### run pipenv install 
### run python main.py  

## CD into frontend/

### run yarn install 
### yarn dev

#### backend runs at 127.0.0.1:5000
#### frontend runs at localhost:5173
